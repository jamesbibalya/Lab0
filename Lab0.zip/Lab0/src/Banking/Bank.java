/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Banking;

/**
 *
 * @author 93343
 */
public interface Bank {
    
    public void Deposit();
    public void Withdraw();
    public float getbalance();
}
